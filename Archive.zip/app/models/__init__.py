from .area import Area
from .catalogo import Catalogo
from .tipo_maquina import TipoMaquina
from .diagrama_de_flujo import DiagramaDeFlujo
from .proceso import Proceso
from .procesos_dependencias import ProcesoDependencia
from .receta import Receta
from .materia_model import Materia



