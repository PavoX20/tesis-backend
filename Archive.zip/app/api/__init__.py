# Marca la carpeta 'app' como paquete raíz.
# No es necesario importar nada aquí.